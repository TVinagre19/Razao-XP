/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "fd75c303a08a57e8ac82680600144545"
  }, {
    "url": "pwa-512x512.png",
    "revision": "82521f8e099ef54bdecac37f271bc0f2"
  }, {
    "url": "pwa-192x192.png",
    "revision": "cf1bca8b54cb8e187e3adcafef2d2dad"
  }, {
    "url": "index.html",
    "revision": "e5568474639510f7b30ba43ba6a35765"
  }, {
    "url": "icon.svg",
    "revision": "948f31249b590667831c82300fe90e64"
  }, {
    "url": "favicon.png",
    "revision": "56842450cdabc94906fc9add5d02504e"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "8c13e8a54d13cd9f765026c6bdce719b"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-DzkYmiUF.js",
    "revision": null
  }, {
    "url": "assets/index-BsGScHOA.css",
    "revision": null
  }, {
    "url": "assets/aistudio/index_73e89b6b.html",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "8c13e8a54d13cd9f765026c6bdce719b"
  }, {
    "url": "favicon.png",
    "revision": "56842450cdabc94906fc9add5d02504e"
  }, {
    "url": "icon.svg",
    "revision": "948f31249b590667831c82300fe90e64"
  }, {
    "url": "pwa-192x192.png",
    "revision": "cf1bca8b54cb8e187e3adcafef2d2dad"
  }, {
    "url": "pwa-512x512.png",
    "revision": "82521f8e099ef54bdecac37f271bc0f2"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "fd75c303a08a57e8ac82680600144545"
  }, {
    "url": "manifest.webmanifest",
    "revision": "a3fcbded98352595f83f141e8f5ea7c8"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
